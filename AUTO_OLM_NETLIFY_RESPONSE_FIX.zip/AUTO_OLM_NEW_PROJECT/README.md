# AUTO OLM — dự án mới (Netlify)

## Cấu trúc
- `public/index.html`: giao diện đăng nhập nguồn đã cung cấp.
- `public/dashboard.html`: giao diện bảng điều khiển nguồn đã cung cấp.
- `netlify/functions/`: proxy đăng nhập, phiên, đăng xuất, tải bài, làm bài và lấy đáp án.
- `netlify.toml`: route cho Netlify Functions.

## Triển khai
1. Tải ZIP, giải nén.
2. Tạo repository GitHub mới (ví dụ `AUTO-OLM-NEW`) và tải toàn bộ nội dung thư mục này lên nhánh `main`.
3. Netlify → Add new project → Import from GitHub → chọn repository.
4. Publish directory: `public`; functions directory: `netlify/functions`; build command để trống.
5. Deploy.
6. Nếu cần đổi máy chủ panel, đặt biến `OLM_PANEL_BASE_URL` trong Netlify Environment variables.

## Kiểm tra và giới hạn
Gói này là bản khởi tạo dựa trên hai trang HTML bạn đã cung cấp. Mã nguồn trang chỉ cho biết các route `/login`, `/panel/exercises`, `/panel/do-exercises`, `/panel/get-answers` và payload frontend; nó không cung cấp tài liệu API hay backend của panel. Vì vậy adapter đang thử giao tiếp trực tiếp với `https://olm.shopntt.bond`, nhưng **chưa được xác minh bằng tài khoản thử nghiệm và không thể cam kết đăng nhập/làm bài/lấy đáp án hoạt động**. Nếu panel thay đổi cơ chế CSRF, cookie, redirect hoặc định dạng request, cần chỉnh adapter. Không đưa mật khẩu, cookie hay token vào GitHub.

Các token CSRF tĩnh có trong HTML nguồn đã bị loại bỏ; mật khẩu chỉ được gửi từ form đăng nhập đến endpoint proxy.
